For this program, command line arguments are used
to obtain the first attempt at the input and
output filenames

Therefore to run the program, the command is:

./Project_06 inputFilename  outputFilename

i.e.
./Project_06 P6_in1.txt  out1.txt


